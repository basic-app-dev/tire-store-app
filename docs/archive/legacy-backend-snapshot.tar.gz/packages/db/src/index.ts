import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';

export * from './schema';

const connectionString =
  process.env.DATABASE_URL || 'postgres://postgres:postgres@127.0.0.1:54322/postgres';

export const client = postgres(connectionString, { prepare: false });
export const db = drizzle(client, { schema });
