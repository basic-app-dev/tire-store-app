#!/usr/bin/env bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=============================================================="
echo "🛑 Stopping Tire Store Application Services"
echo "=============================================================="

# Stop Frontend Web
"${SCRIPT_DIR}/stop-frontend.sh"

echo ""
echo "=============================================================="
echo "✅ All Tire Store application processes stopped."
echo "=============================================================="
