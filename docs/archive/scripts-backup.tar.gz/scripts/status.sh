#!/usr/bin/env bash

# Resolve repository root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "=============================================================="
echo "📊 Tire Store App — System Service Status"
echo "=============================================================="

# 1. Frontend Web (Port 3000)
if lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null 2>&1; then
  FRONTEND_PID=$(lsof -Pi :3000 -sTCP:LISTEN -t | head -n 1)
  echo "🟢 Frontend Web:        ONLINE  (Port 3000, PID: ${FRONTEND_PID}) -> http://localhost:3000"
else
  echo "⚪ Frontend Web:        OFFLINE (Port 3000)"
fi

# 2. Mobile Expo Server (Port 8081)
if lsof -Pi :8081 -sTCP:LISTEN -t >/dev/null 2>&1; then
  MOBILE_PID=$(lsof -Pi :8081 -sTCP:LISTEN -t | head -n 1)
  echo "🟢 Mobile Server:       ONLINE  (Port 8081, PID: ${MOBILE_PID}) -> http://localhost:8081"
else
  echo "⚪ Mobile Server:       OFFLINE (Port 8081)"
fi

echo "--------------------------------------------------------------"
echo "☕ Spring Boot Microservices (Java 25 LTS):"

SERVICES=(
  "automotive-operations:8091"
  "automotive-product:8092"
  "vehicle-sales:8093"
  "vehicle-product:8094"
  "notification:8095"
  "identity-access:8096"
  "appointment:8097"
  "store-management:8098"
)

for SVC in "${SERVICES[@]}"; do
  NAME="${SVC%%:*}"
  PORT="${SVC##*:}"
  if lsof -Pi :${PORT} -sTCP:LISTEN -t >/dev/null 2>&1; then
    PID=$(lsof -Pi :${PORT} -sTCP:LISTEN -t | head -n 1)
    printf "🟢 %-22s ONLINE  (Port %s, PID: %s)\n" "${NAME}" "${PORT}" "${PID}"
  else
    printf "⚪ %-22s OFFLINE (Port %s)\n" "${NAME}" "${PORT}"
  fi
done

echo "=============================================================="
