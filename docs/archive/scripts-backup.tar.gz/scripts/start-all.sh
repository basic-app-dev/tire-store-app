#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=============================================================="
echo "⚡ Starting Tire Store Frontend Stack"
echo "=============================================================="

# Start Frontend Web
"${SCRIPT_DIR}/start-frontend.sh"

echo ""
echo "=============================================================="
echo "🎉 FRONTEND SERVICE ONLINE!"
echo "=============================================================="
echo "🌐 Frontend Web:  http://localhost:3000"
echo "📊 Check Status:  ./scripts/status.sh"
echo "🛑 Stop All:      ./scripts/stop-all.sh"
echo "=============================================================="
